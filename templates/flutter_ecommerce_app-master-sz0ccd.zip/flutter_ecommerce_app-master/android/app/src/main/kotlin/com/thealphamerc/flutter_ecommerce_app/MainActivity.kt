package com.thealphamerc.flutter_ecommerce_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
