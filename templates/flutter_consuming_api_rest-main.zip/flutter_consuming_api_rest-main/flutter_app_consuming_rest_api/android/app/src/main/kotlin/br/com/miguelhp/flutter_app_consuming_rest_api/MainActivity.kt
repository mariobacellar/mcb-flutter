package br.com.miguelhp.flutter_app_consuming_rest_api

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
