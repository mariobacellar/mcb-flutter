package br.com.tutoriais.flutter_ui_plantapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
