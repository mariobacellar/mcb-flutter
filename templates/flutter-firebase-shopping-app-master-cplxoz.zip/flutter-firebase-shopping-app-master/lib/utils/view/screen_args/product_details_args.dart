class ProductDetailsArgs {
  String id;
  int index;

  ProductDetailsArgs({
    this.id,
    this.index,
  });
}
