class Product
{
  String name,
        price,
        image;
  bool userLiked;
  double discount;

  Product({
    this.name,
    this.price,
    this.discount,
    this.image,
    this.userLiked
  });

}