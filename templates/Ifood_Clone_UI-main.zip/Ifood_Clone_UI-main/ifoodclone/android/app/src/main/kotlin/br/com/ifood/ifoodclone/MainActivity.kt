package br.com.ifood.ifoodclone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
