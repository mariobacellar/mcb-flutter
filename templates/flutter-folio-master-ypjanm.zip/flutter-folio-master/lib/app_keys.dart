class AppKeys {
  static String cloudinaryCloud = "flutterfoliodemo";
  static String cloudinaryPreset = "ujszrrfn";
  static String firebaseApiKey = "AIzaSyDIMnzUz9TshIyRSSl7iUpp5QxPhAcL1ZQ";
  static String firestoreProjectId = "flutter-folio-demo";
}
