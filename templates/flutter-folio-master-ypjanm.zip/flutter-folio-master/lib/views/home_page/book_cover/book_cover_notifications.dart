import 'package:flutter/material.dart';

class BookEditingNotification extends Notification {
}

class BookEditingStartedNotification extends BookEditingNotification {
}

class BookEditingEndedNotification extends BookEditingNotification {
}

