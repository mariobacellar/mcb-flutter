import 'package:flutter/material.dart';

class CloseNotification extends Notification {}
