package br.com.examples.rest_call_api_http_methods

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
