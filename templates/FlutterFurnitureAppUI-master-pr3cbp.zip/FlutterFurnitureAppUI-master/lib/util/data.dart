List furnitures = [
  {
    "name": "Living Room",
    "img": "assets/1.jpeg",
  },
  {
    "name": "Dining Room",
    "img": "assets/4.jpeg",
  },
  {
    "name": "Bed Room",
    "img": "assets/3.jpeg",
  },
  {
    "name": "Dining Room",
    "img": "assets/2.jpeg",
  },
];
