package br.com.cod3r.expenses

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
