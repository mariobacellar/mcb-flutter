package br.com.cod3r.flexible_expanded

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
