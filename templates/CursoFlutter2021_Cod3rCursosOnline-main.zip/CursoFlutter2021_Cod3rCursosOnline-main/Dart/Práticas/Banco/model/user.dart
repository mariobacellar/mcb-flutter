class User {
  String? userName;
  String? cpf;

  User({required this.userName, this.cpf});
}
