//FUNCÕES ANONIMAS

main() {
  var adicao = (int a, int b) {
    return a + b;
  };

  print(adicao(4, 9));

  var subtracao = (int a, int b) => a - b;

  print(subtracao(5, 4));
}

//  -------------------------
//13
//1