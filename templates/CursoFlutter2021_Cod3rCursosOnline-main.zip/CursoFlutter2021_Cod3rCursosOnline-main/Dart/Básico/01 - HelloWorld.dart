main(){
  print('Hello World');
}