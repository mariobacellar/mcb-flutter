import 'Pessoa.dart';

main() {
  var pessoa01 = Pessoa();

  pessoa01.nome = 'Miguel';

  print(pessoa01.nome);
}
