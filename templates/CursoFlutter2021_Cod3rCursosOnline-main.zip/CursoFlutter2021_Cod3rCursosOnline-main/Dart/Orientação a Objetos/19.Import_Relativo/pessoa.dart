class Pessoa {
  String? nome;
}
