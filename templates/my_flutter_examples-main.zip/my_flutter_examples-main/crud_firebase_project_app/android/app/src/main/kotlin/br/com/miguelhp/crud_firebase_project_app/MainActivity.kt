package br.com.miguelhp.crud_firebase_project_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
