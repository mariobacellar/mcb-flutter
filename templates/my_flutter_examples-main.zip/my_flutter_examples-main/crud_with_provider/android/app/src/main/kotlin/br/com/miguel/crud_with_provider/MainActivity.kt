package br.com.miguel.crud_with_provider

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
