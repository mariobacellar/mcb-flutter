package br.com.miguelhp.splash_screen_and_login_page

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
