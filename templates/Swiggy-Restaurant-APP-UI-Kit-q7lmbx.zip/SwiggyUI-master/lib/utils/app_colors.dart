import 'package:flutter/material.dart';

const Color appColor = Colors.orange;
Color? darkOrange = Colors.deepOrange[800];
Color? swiggyOrange = Colors.orange[900];
