package com.lucasalgado.dioapp.dioproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
